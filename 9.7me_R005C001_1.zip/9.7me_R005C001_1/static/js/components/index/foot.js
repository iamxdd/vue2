define(function(){
        var html = "<div class='footContainer' style='opacity: 1'><div class='copyRight'>"+
            "COPYRIGHT 2016-2017 成都四方伟业软件股份有限公司 版权所有 蜀ICP备14024109号-1</div></div>";

        return {
            template:html
        }
});